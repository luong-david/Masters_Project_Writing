#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 27 15:16:11 2021

@author: harshittrehan
"""

import glob
import numpy as np
import math
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.metrics import roc_curve, auc

opdict = {}

N = 2
M = 20
T = 1200

pi = np.empty(N, dtype = np.float64)
A = np.empty(N*N, dtype = np.float64)
B = np.empty(N*M, dtype = np.float64)

test_obs_seq = np.empty(T, dtype = np.int32)
alpha = np.zeros([T,N], dtype = np.float64)
scaling = np.zeros(T, dtype = np.float64)

scores = []
labels = [1]*500 + [-1]*1000

df = pd.DataFrame()

def opcodeMapping(family):
    global opdict
    
    opfreq = {}
    
    with open("obseq%s.txt"%family, "r") as f:
        for line in f:
            line = line.strip()
            if line not in opfreq:
                opfreq[line] = 1
            else:
                opfreq[line] += 1
    
    tup = sorted(opfreq.items(), key=lambda x:x[1], reverse=True)

    for i in range(0, M-1):
        opdict[tup[i][0]] = i
    #print(opdict)
    
def loadModel():
    global pi, A, B, N, M
    
    pi = np.loadtxt("matrices/bestPi" + str(M) + ".txt", delimiter='\n')
    A = np.loadtxt("matrices/bestA" + str(M) + ".txt", delimiter='\n')
    B = np.loadtxt("matrices/bestB" + str(M) + ".txt", delimiter='\n')
    B=B.reshape((N,M))
    A=A.reshape((N,N))
    
    for i in range (0, N):
        for j in range (0, M):
            if B[i][j] < 1.0e-9:
                B[i][j] = 0
            #if A[i][j] < 1.0e-9:
                #A[i][j] = 0
                
def alphaPassTest():
    global N, M, T, pi, A, B, alpha, scaling, test_obs_seq

    scaling[0]=0
    for i in range(0, N):
        alpha[0][i] = pi[i]*B[i][test_obs_seq[0]]
        scaling[0] = scaling[0] + alpha[0][i]
    
    if scaling[0] == 0 or scaling[0]< 1.0e-300:
        scaling[0] = 1/1.0e-9
    else:
        scaling[0] = 1/scaling[0]
    
    for i in range(0, N):
        alpha[0][i] = scaling[0]*alpha[0][i]
    
    for t in range(1, T):
        scaling[t]=0
        for i in range(0, N):
            alpha[t][i]=0.0
            for j in range(0, N):
                alpha[t][i] = alpha[t][i]+alpha[t-1][j]*A[j][i]
            
            alpha[t][i] = alpha[t][i]*B[i][test_obs_seq[t]]
            scaling[t] = scaling[t] + alpha[t][i]
        
        if scaling[t] == 0 or scaling[t]< 1.0e-300:
            scaling[t] = 1/1.0e-9
        else:
            scaling[t] = 1/scaling[t]
        
        for i in range(0, N):
            alpha[t][i] = scaling[t] * alpha[t][i]
            
    probability = 0.0
    for t in range(0, T):
        probability += math.log(scaling[t], math.e)
    
    return -1*probability

def readAndScoreTestFiles(files, samplesNum):
    global scores, M, T, test_obs_seq, opdict
    
    for file in files:
        i=0
        with open(file, "r") as f:
            for line in f:
                line = line.strip()
                if line in opdict:
                    test_obs_seq[i] = opdict[line]
                else:
                    test_obs_seq[i] = M-1
                i += 1
                if i >= T:
                    break
        prob = alphaPassTest()
        #print('Probability for: ', file, ' = ', alphaPassTest())
        scores.append(prob)
        samplesNum -= 1
        if samplesNum ==0:
            break

def testRunner(family):
    global opdict, test_obs_seq, M, df, T, scores, labels
    
    '''    
    allFamilies = ['Renos', 'WinWebSec', 'OnLineGames', 'VBInject', 'Zbot']

    filesCurr = sorted(glob.glob(family+'test/*.txt'))
    readAndScoreTestFiles(filesCurr, 500)

    for fam in allFamilies:
        path = fam+'test/*.txt'
        files = sorted(glob.glob(path))
        if not fam == family:
            readAndScoreTestFiles(files, 100)
    
    files = glob.glob('../benignTest/*.txt')
    readAndScoreTestFiles(files, 500)
    '''
    
    winTest = sorted(glob.glob('wintest/*.txt'))
    zbotTest = sorted(glob.glob('../zbottest/*.txt')) 
    zaccessTest = sorted(glob.glob('../zaccesstest/*.txt'))
    ogTest = sorted(glob.glob('OnLineGamestest/*.txt'))
    
    readAndScoreTestFiles(ogTest,500)
    readAndScoreTestFiles(zbotTest,500)
    readAndScoreTestFiles(zaccessTest,500)

    # df = pd.DataFrame(list(zip(scores, labels)), columns =['Score', 'Label'])
    # df['x1'] = df.index
    
    # plt.scatter(x=df.x1, y=df.Score, s=5, c=df.Label)
    # plt.title('M = '+ str(M))
    # plt.show()

def createFig(results, family):
    r, c = 5, 4
    m = 20
    fig, axs = plt.subplots(r, c, figsize=(11,11))
    for i in range(r):
        for j in range(c):
            fpr, tpr, roc_auc = results[m]
            axs[i,j].plot(fpr, tpr, color='darkorange', label='ROC Curve')
            m += 1
    m=20
    for ax in axs.flat:
        _,_,auc = results[m]
        ax.set_title('M = %d, AUC=%0.5f' % (m, auc), fontdict={'fontsize':10})
        m += 1
    fig.suptitle('ROC Curves for %s'%family, fontsize=14, y=.95)
    fig.text(0.5, 0.06, 'False Positive Rate', ha='center', fontdict={'fontsize':13})
    fig.text(0.06, 0.5, 'True Positive Rate', va='center', rotation='vertical', fontdict={'fontsize':13})
    fig.subplots_adjust(hspace=.5)
    lines, labels = fig.axes[-1].get_legend_handles_labels()
    
    fig.legend(lines, labels, loc = 'lower right', bbox_to_anchor=(0.95, 0.05), prop={'size': 13})
    fig.savefig("../images/initalROC%s.png"%family)

def createBar(results, family):
    x = [i for i in range(20,41)]
    y = [val[1][2] for val in results.items()]
    
    fig, axs = plt.subplots(figsize=(9,6))

    axs.bar(x, y, width=0.5)
    axs.set_xticks([i for i in range(20, 41)])
    axs.set_xlabel('Value of M')
    axs.set_ylabel('AUC Score')
    axs.set_title('%s Optimum M Scores'%family)
    axs.set_ylim([0, 1.1])
    
    for i, v in enumerate(y):
        axs.text(i+20, v+0.07, str(np.format_float_positional(v, precision=3)), va='center', ha='center', color='black', rotation=90)
    
    fig.savefig("%s_hmm_optimum_M.png"%family)
    plt.show()

def runner():
    global M, scores, labels

    results = {}
    family = 'OnLineGames'
    
    for M in range(20, 41):
        opcodeMapping(family)
        loadModel()
        testRunner(family)
        fpr, tpr, _ = roc_curve(labels, scores)
        roc_auc = auc(fpr, tpr)
        print('AUC for M = ', M, 'is: ', roc_auc)
        results[M] = [fpr, tpr, roc_auc]    
        scores = []

    #createFig(results, family)
    createBar(results, family)

runner()