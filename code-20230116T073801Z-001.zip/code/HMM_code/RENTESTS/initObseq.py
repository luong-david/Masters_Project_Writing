#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 26 10:41:43 2021

@author: harshittrehan
"""
import json
opdict = {}
with open("obseqRenos.txt", "r") as rf:
    for line in rf:
        line = line.strip()
        if line not in opdict:
            opdict[line] = 1
        else:
            opdict[line] += 1

tup = sorted(opdict.items(), key=lambda item: item[1], reverse=True)
opdict = {}
for i in range(0, 21):
    opdict[tup[i][0]] = i

print(opdict)

'''
with open("obseqIntPyth.txt", "w") as wf:
    with open("obseqWWS.txt", "r") as rf:
        for line in rf:
            line = line.strip()
            if line not in opdict:
                wf.write(str(21)+"\n")
            else:
                wf.write(str(opdict[line])+"\n")
'''

with open("opdictRenos.json", "w") as wf:
    json.dump(opdict, wf)