//
//  main.cpp
//  code
//
//  Created by Harshit Trehan on 10/11/20.
//  Copyright © 2020 Harshit Trehan. All rights reserved.
//
#include <iostream>
#include <string>
#include <fstream>
#include <limits>
#include <cstdlib>
#include <math.h>
#include <float.h>
#include <string>
#include <unordered_map>
#include <vector>
#include <unordered_set>

using namespace std;

#define N 2
#define M 23
#define maxIterations 500
#define T 30000
#define n 10000

#define Abbr "WWS"

#define Ttest 300
int test_obs_seq[Ttest];
double alphaTest[Ttest][N];
double scalingTest[Ttest];

unordered_map<string, int> map;
unordered_map<int, int> new_val;

int obs_seq[T];

double bestA[N][N];
double bestB[N][M];
double bestPi[N];
double bestGama[T][N];
double bestScore = -INFINITY;

double A[N][N] = {};

double B[N][M] = {};

double pi[N] = {};

double scaling[T];
double alpha[T][N];
double beta[T][N];
double gama[T][N];
double digama[T][N][N];

void randomGen(int seed){
    srand(seed);
    
    // Generating PI matrix
    double sum=0.0;
    for(int i=0; i<N; i++){
        pi[i] = rand();
        sum+=pi[i];
    }
    for(int i=0; i<N; i++){
        pi[i] = pi[i]/sum;
    }
    
    // Generating B matrix
    double Bsum[N]={};
    for(int i=0; i<N; i++){
        for(int j=0; j<M; j++){
            B[i][j] = rand();
            Bsum[i] +=B[i][j];
        }
    }
    for(int i=0; i<N; i++){
        for(int j=0; j<M; j++){
            B[i][j] = B[i][j]/Bsum[i];
        }
    }
    
    // Generating A matrix
    double Asum[N]={};
    for(int i=0; i<N; i++){
        for(int j=0; j<N; j++){
            A[i][j] = rand();
            Asum[i] += A[i][j];
        }
    }
    for(int i=0; i<N; i++){
        for(int j=0; j<N; j++){
            A[i][j] = A[i][j]/Asum[i];
        }
    }
    
}

static void alphaPass(){
    scaling[0]=0;
    for(int i=0; i<N; i++){
        alpha[0][i] = pi[i]*B[i][obs_seq[0]];
        scaling[0] = scaling[0] + alpha[0][i];
    }
    scaling[0] = 1/scaling[0];
    for(int i=0; i<N; i++){
        alpha[0][i] = scaling[0]*alpha[0][i];
    }

    for(int t=1; t<T; t++){
        scaling[t]=0;
        for(int i=0; i<N; i++){
            alpha[t][i]=0.0;
            for(int j=0; j<N; j++){
                alpha[t][i] = alpha[t][i]+alpha[t-1][j]*A[j][i];
            }
            alpha[t][i] = alpha[t][i]*B[i][obs_seq[t]];
            scaling[t] = scaling[t] + alpha[t][i];
        }
        scaling[t] = 1/scaling[t];
        for(int i=0; i<N; i++){
            alpha[t][i] = scaling[t] * alpha[t][i];
        }
    }
}

static void betaPass(){
    for(int i=0; i<N; i++){
        beta[T-1][i] = scaling[T-1];
    }
    for(int t=T-2; t>=0; t--){
        for(int i=0; i<N; i++){
            beta[t][i] = 0;
            for(int j=0; j<N; j++){
                beta[t][i] = beta[t][i] + A[i][j]*B[j][obs_seq[t+1]]*beta[t+1][j];
            }
            beta[t][i] = scaling[t] * beta[t][i];
        }
    }
}

static void gamaPass(){
    double denom;
    for(int t=0; t<=T-2; t++){
        denom = 0;
        for(int i=0; i<N; i++){
            for(int j=0; j<N; j++){
                denom = denom + alpha[t][i]*A[i][j]*B[j][obs_seq[t+1]]*beta[t+1][j];
            }
        }
        for(int i=0; i<N; i++){
            gama[t][i] = 0;
            for(int j=0; j<N; j++){
                digama[t][i][j] = (alpha[t][i]*A[i][j]*B[j][obs_seq[t+1]]*beta[t+1][j])/denom;
                gama[t][i] = gama[t][i] +  digama[t][i][j];
            }
        }
    }

    denom = 0;
    for(int i=0; i<N; i++){
        denom = denom + alpha[T-1][i];
    }
    for(int i=0; i<N; i++){
        gama[T-1][i] = alpha[T-1][i]/denom;
    }
}

static void reestimate(){
    double numer;
    double denom;
    for(int i=0; i<N; i++){
        pi[i] = gama[0][i];
    }

    for(int i=0; i<N; i++){
        for(int j=0; j<M; j++){
            numer = 0;
            denom = 0;
            for(int t=0; t<T; t++){
                if(obs_seq[t] == j){
                    numer = numer + gama[t][i];
                }
                denom = denom + gama[t][i];
            }
            B[i][j] = numer/denom;
        }
    }
}

static double calcProb(){
    double logProb=0;
    for(int i=0; i<T; i++){
        logProb = logProb + log(scaling[i]);
    }
    return -1*logProb;
}

void printMatrices(){
    string AMat = "/Users/harshittrehan/Desktop/CS297/code/code/" + string(Abbr) + "TESTS/yash/bestA" + to_string(M) + ".txt";
    string BMat = "/Users/harshittrehan/desktop/cs297/code/code/"+ string(Abbr) + "TESTS/yash/bestB" + to_string(M) + ".txt";
    string PiMat = "/Users/harshittrehan/desktop/cs297/code/code/" + string(Abbr) + "TESTS/yash/bestPi" + to_string(M) + ".txt";
    string gammaMat = "/Users/harshittrehan/desktop/cs297/code/code/" + string(Abbr) + "TESTS/yash/gamma" + to_string(M) + ".txt";
    
    ofstream gamma(gammaMat);
    ofstream pi(PiMat);
    ofstream a(AMat);
    ofstream b(BMat);
    
    for(int i=0; i<N; i++){
        pi<<bestPi[i]<<"\n";
    }

    for(int i=0; i<N; i++){
        for(int j=0; j<M; j++){
            b<<bestB[i][j]<<"\n";
        }
    }
    
    for(int i=0; i<N; i++) {
        for(int j=0; j<N; j++) {
            a<<bestA[i][j]<<"\n";
        }
    }
    
    for(int t=0; t<T; t++){
        double max = -DBL_MIN;
        int op = -1;
        for(int j=0; j<N; j++){
            if(bestGama[t][j] > max){
                max = bestGama[t][j];
                op = j;
            }
        }
        gamma<<op<<"\n";
    }
    
    gamma.close();
    pi.close();
    a.close();
    b.close();
}

void runner() {
    cout<<"M = "<<M<<" Family: "<< Abbr;
    int seeed;
    cout<<"Enter seed value for random generator: ";
    cin>>seeed;
    cout<<endl;
    srand(seeed);
    
    int iterations=0;
    for(int i=0; i<=n-1; i++){
        iterations=0;
        cout<<endl<<endl<<"Random restart number: "<<i+1<<endl;
        randomGen(rand());
        double logProb = 0.0;
        cout<<"Re-estimating the models....."<<endl;
        while(iterations<maxIterations){
            alphaPass();
            betaPass();
            gamaPass();
            logProb = calcProb();
            reestimate();
            cout<<"New log probability: "<<setprecision(5)<<fixed<<logProb<<endl;
            iterations++;
        }
        
        if(logProb>bestScore) {
            memcpy(bestA, A, N*N*sizeof(double));
            memcpy(bestB, B, N*M*sizeof(double));
            memcpy(bestPi, pi, N*sizeof(double));
            memcpy(bestGama, gama, T*N*sizeof(double));
            bestScore = logProb;
        }
    }
}

void getObSeq() {
    unordered_map<int, int> freq_map;
    vector<pair<int, int>> freq;
    
    for(int i=0; i<T; i++){
        freq_map[obs_seq[i]]++;
    }
    
    for (auto itr = freq_map.begin(); itr != freq_map.end(); ++itr) {
        freq.push_back(*itr);
    }
    
    sort(freq.begin(), freq.end(), [=](pair<int, int>& a, pair<int, int>& b) {
        return a.second > b.second;
    });
    
    for(int i=0; i<M-1; i++) {
        new_val[freq[i].first] = i;
    }
    for(auto const& it : new_val){
        cout<<it.first<< " : "<< it.second<<endl;
    }
    cout<<new_val.size();
    
    for(int i=0; i<T; i++){
        if(new_val.find(obs_seq[i]) == new_val.end()) {
            obs_seq[i] = M-1;
        }
        else {
            obs_seq[i] = new_val[obs_seq[i]];
        }
    }
}

int main() {
    
    string opcd = "/Users/harshittrehan/Desktop/CS297/code/code/" + string(Abbr) + "TESTS/opcodesWinWebSec.txt";
    string obseq = "/Users/harshittrehan/Desktop/CS297/code/code/" + string(Abbr) + "TESTS/obseqWinWebSec.txt";
    
    ifstream opcode;
    opcode.open(opcd);
    
    int count = 0;
    for( string line; getline( opcode, line ); ) {
        map[line] = count;
        count++;
    }
    
    //Observation sequence of 30000 length for training
    ifstream infile;
    infile.open(obseq);
    
    int i=0;
    for( string line; getline( infile, line ); ) {
        if ( map.find(line) == map.end() ) {
            cout<<"Not found";
        }
        else {
            obs_seq[i] = map[line];
            i++;
        }
    }

    getObSeq();
    runner();
    printMatrices();
    
    opcode.close();
    infile.close();
    
    return 0;

}
