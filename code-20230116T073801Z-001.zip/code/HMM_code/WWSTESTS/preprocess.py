#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 11 22:25:58 2020

@author: harshittrehan
"""
import glob
import os

class Preprocess():
    def __init__(self, family):
        self.family = family
        self.dataPath = "../DATA/malware (opcodes)/"
        self.obseqLen = 30000
        self.testSamples = 100
        self.testLen = 1200
    
    def makeObseq(self):
        files = glob.glob(self.dataPath + self.family + "/*.txt")
        s = set()
        count = 0
        flag = False
        fileNum = 1
        
        with open("obseq" + self.family + ".txt", "w") as wf:
            for file in files:
                if not self.fileLen(file):
                    continue
                if count<self.obseqLen:
                    with open(file, "r") as f:
                        for line in f:
                            if count<self.obseqLen:
                                wf.write(line)
                                count += 1
                            else:
                                break                           
                elif fileNum<=600:
                    if not flag:
                        print("---")
                        flag = True
                        continue
                    else:
                        testCount = 0
                        with open(file, "r") as f:
                            if not os.path.exists(os.path.join(os.getcwd(), self.family+"test/")):
                                print("print 5 times")
                                os.mkdir(os.path.join(os.getcwd(), self.family+"test/"))  
                            with open(self.family + "test/" + str(fileNum) + self.family + ".txt", "w") as tf:
                                for line in f:
                                    if testCount<1200:
                                        tf.write(line)
                                        testCount += 1
                                    else:
                                        testCount = 0
                                        fileNum += 1
                                        break  
                else:
                    break
        with open("obseq" + self.family + ".txt", "r") as f:
            for line in f:
                s.add(line)
        with open("opcodes" + self.family + ".txt", "w") as wf:
            for val in s:
                wf.write(val)
        
    def makeTestFiles(self, testFam):
        fileNum = 1
        files = glob.glob(self.dataPath + testFam + "/*.txt")
        for file in files:
            if not self.fileLen(file):
                continue
            testCount = 0
            if fileNum<=100:
                with open(file, "r") as f:    
                    if not os.path.exists(os.path.join(os.getcwd(), testFam+"test/")):
                        print("print 5 times")
                        os.mkdir(os.path.join(os.getcwd(), testFam+"test/"))                    
                    with open(testFam + "test/" + str(fileNum) + testFam + ".txt" , "w") as wf:
                        for line in f:
                            if testCount<1200:
                                wf.write(line)
                                testCount += 1
                            else:
                                testCount = 0
                                fileNum += 1
                                break
            else:
                break
        
    def fileLen(self, fname):
        sz = 0
        with open(fname, "r") as rf:
            for i,l in enumerate(rf):
                sz = i
                continue
        if sz+1>=self.testLen:
            return True
        else:
            return False

if __name__ == '__main__':
    currentFam = 'WinWebSec'
    pre = Preprocess(currentFam)
    pre.makeObseq()
    allFamilies = ['BHO', 'Renos', 'WinWebSec', 'OnLineGames', 'VBInject', 'Zbot']
    for fam in allFamilies:
        if not fam == currentFam:
            pre.makeTestFiles(fam)
            
            