#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 25 14:19:59 2020

@author: harshittrehan
"""
from multiprocessing import Process, Queue

import glob
import numpy as np
import math
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc

def readAndScoreTestFiles(N, M, T, A, B, pi, opdict, files, samplesNum, label, scores):
    
    test_obs_seq = np.empty(T, dtype = np.int32)
    alpha = np.zeros([T,N], dtype = np.float64)
    scaling = np.zeros(T, dtype = np.float64)
    
    for file in files:
        i=0
        with open(file, "r") as f:
            for line in f:
                line = line.strip()
                if line in opdict:
                    test_obs_seq[i] = opdict[line]
                else:
                    test_obs_seq[i] = M-1
                i += 1
                if i >= T:
                    break
                
        scaling[0]=0
        for i in range(0, N):
            alpha[0][i] = pi[i]*B[i][test_obs_seq[0]]
            scaling[0] = scaling[0] + alpha[0][i]
        
        if scaling[0] == 0 or scaling[0]< 1.0e-300:
            scaling[0] = 1/1.0e-9
        else:
            scaling[0] = 1/scaling[0]
        
        for i in range(0, N):
            alpha[0][i] = scaling[0]*alpha[0][i]
        
        for t in range(1, T):
            scaling[t]=0
            for i in range(0, N):
                alpha[t][i]=0.0
                for j in range(0, N):
                    alpha[t][i] = alpha[t][i]+alpha[t-1][j]*A[j][i]
                
                alpha[t][i] = alpha[t][i]*B[i][test_obs_seq[t]]
                scaling[t] = scaling[t] + alpha[t][i]
            
            if scaling[t] == 0 or scaling[t]< 1.0e-300:
                scaling[t] = 1/1.0e-9
            else:
                scaling[t] = 1/scaling[t]
            
            for i in range(0, N):
                alpha[t][i] = scaling[t] * alpha[t][i]
                
        probability = 0.0
        for t in range(0, T):
            probability += math.log(scaling[t], math.e)
        
        #print('Probability for: ', file, ' = ', alphaPassTest())
        
        scores.put((-1*probability, label))
        
        samplesNum -= 1
        if samplesNum == 0:
            break

if __name__=='__main__':
    opdict = {}
    
    N = 22
    M = 22
    T = 1200    
    
    opfreq = {}
    family = 'WinWebSec'
    with open("obseq%s.txt"%family, "r") as f:
        for line in f:
            line = line.strip()
            if line not in opfreq:
                opfreq[line] = 1
            else:
                opfreq[line] += 1
    
    tup = sorted(opfreq.items(), key=lambda x:x[1], reverse=True)

    for i in range(0, M-1):
        opdict[tup[i][0]] = i
    
    models = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']
    #models = ['']
    results = {}

    for model in models:
        pi = np.loadtxt("problem2MatricesBest/%s/bestPi"%model + str(M) + ".txt", delimiter='\n')
        A = np.loadtxt("problem2MatricesBest/%s/bestA"%model + str(M) + ".txt", delimiter='\n')
        B = np.loadtxt("problem2MatricesBest/%s/bestB"%model + str(M) + ".txt", delimiter='\n')
        
        B = B.reshape((N,M))
        A = A.reshape((N,N))
        
        for i in range (0, N):
            for j in range (0, M):
                if B[i][j] < 1.0e-9:
                    B[i][j] = 0
                if A[i][j] < 1.0e-9:
                    A[i][j] = 0
    
        '''
        allFamilies = ['BHO', 'Renos', 'WinWebSec', 'OnLineGames', 'VBInject', 'Zbot']
        filesCurr = sorted(glob.glob(family+'test/*.txt'))
        readAndScoreTestFiles(filesCurr, 600) 
        for fam in allFamilies:
            path = fam+'test/*.txt'
            files = sorted(glob.glob(path))
            if not fam == family:
                readAndScoreTestFiles(files, 100)
        files = glob.glob('../benignTest/*.txt')
        readAndScoreTestFiles(files, 100)
        '''
        winTest = sorted(glob.glob('../wintest/*.txt'))
        zbotTest = sorted(glob.glob('../zbottest/*.txt')) 
        zaccessTest = sorted(glob.glob('../zaccesstest/*.txt'))
        ogTest = sorted(glob.glob('../OGTESTS/OnLineGamestest/*.txt'))
        renTest = sorted(glob.glob('../RENTESTS/Renostest/*.txt'))
        vbiTest = sorted(glob.glob('../VBITESTS/VBInjecttest/*.txt'))
        
        #print(len(winTest), len(zbotTest), len(zaccessTest), len(ogTest), len(renTest), len(vbiTest))
        
        scores = Queue()
    
        proc1 = Process(target=readAndScoreTestFiles, args=(N, M, T, A, B, pi, opdict, winTest[:250], 250, 1, scores))
        proc2 = Process(target=readAndScoreTestFiles, args=(N, M, T, A, B, pi, opdict, winTest[250:], 250, 1, scores))
        
        proc3 = Process(target=readAndScoreTestFiles, args=(N, M, T, A, B, pi, opdict, zbotTest[:250], 250, -1, scores))
        proc4 = Process(target=readAndScoreTestFiles, args=(N, M, T, A, B, pi, opdict, zbotTest[250:], 250, -1, scores))
        
        proc5 = Process(target=readAndScoreTestFiles, args=(N, M, T, A, B, pi, opdict, zaccessTest[:250], 250, -1, scores))
        proc6 = Process(target=readAndScoreTestFiles, args=(N, M, T, A, B, pi, opdict, zaccessTest[250:], 250, -1, scores))
        
        proc1.start()
        proc2.start()
        proc3.start()
        proc4.start()
        proc5.start()
        proc6.start()
        
        proc1.join()
        proc2.join()
        proc3.join()
        proc4.join()
        proc5.join()
        proc6.join()
        
        print('DONE')
        
        total = 1500
        scores = [scores.get() for i in range(total)]
        
        #print(scores)
        
        scorez = [val[0] for val in scores]
        labels = [val[1] for val in scores]
        fpr, tpr, _ = roc_curve(labels, scorez)
        roc_auc = auc(fpr, tpr)
        print('AUC for model %s is %f ' % (model, roc_auc))
        results[model] = roc_auc
    
    fig, axs = plt.subplots()
    y = results.values()
    axs.bar(models, y, width=0.5, color='red')
    axs.set_ylim([0, 1.1])
    axs.set_xlabel('HMM Models #')
    axs.set_ylabel('AUC Score')
    axs.set_title('%s HMM Model Scores'%family)
    for i, v in enumerate(y):
        axs.text(i, v+0.09, str(np.format_float_positional(v, precision=3)), va='center', ha='center', color='black', rotation=90)
    
    fig.savefig("%s_hmm_score_bar.png"%family)
