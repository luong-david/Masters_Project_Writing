#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Apr 29 23:54:47 2021

@author: harshittrehan
"""

import os
import tensorflow
import numpy as np
import data_loader as data
import matplotlib.pyplot as plt
import collections

from tensorflow.keras.models import load_model
from tensorflow.keras.layers import LeakyReLU

from gensim.models import Word2Vec

from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier

from sklearn.model_selection import KFold, cross_val_score
from sklearn.model_selection import train_test_split
from sklearn.metrics import plot_confusion_matrix, classification_report
from sklearn.metrics import confusion_matrix, recall_score, precision_score

from nltk.util import ngrams

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
tensorflow.compat.v1.logging.set_verbosity(tensorflow.compat.v1.logging.ERROR)

class fake_GAN_test_runner():
    def __init__(self, mw_family, file_len, num_samples, epoch, architecture):
        self.mw_family = mw_family
        self.latent_dim = 100
        self.file_len = file_len
        self.real_samples, self.num_unique = data.real_loader(self.mw_family, 600).load_real(True)
        self.num_samples = num_samples
        self.factor = self.num_unique/2.
        self.epoch = epoch
        self.architecture = architecture
        self.generator = load_model('../GAN/%s_Results/Models_test/%s/%s_generator_%d.hdf5' % (self.architecture, self.mw_family, self.mw_family, self.epoch), custom_objects={'LeakyReLU': LeakyReLU})
        self.fake_samples = self.generate()
        print('Family: %s, Num_unique: %d, Num_samples: %d, Factor: %f, Epoch: %d, Architecture: %s' % (self.mw_family, self.num_unique, self.num_samples, self.factor, self.epoch, self.architecture))
    
    def generate(self):
        noise = np.random.normal(0, 1, (self.num_samples, self.latent_dim))
        gen_samples = self.generator.predict(noise)
        gen_samples = (gen_samples + 1) * self.factor
        gen_samples = np.rint(gen_samples)
        gen_samples = gen_samples.astype(int)
        gen_samples = np.reshape(gen_samples, (self.num_samples, 600))
        return gen_samples

    def integer_vectors(self):
        print('Integer vectors')
        idx = np.random.randint(0, self.real_samples.shape[0], self.num_samples)
        real_data_sampled = self.real_samples[idx]
        
        X = np.concatenate((real_data_sampled, self.fake_samples))
        
        return X
        
    def word2vec_embed(self):
        print('Word2Vec')
        # Create W2V embeddings based on real samples
        
        #real_data = self.real_samples.tolist()
        #model = Word2Vec(sentences=real_data, vector_size=100, window=5, min_count=1, workers=4)
        #model.save("word2vec_%s.model"%self.mw_family)
        
        model = Word2Vec.load("word2vec_%s.model"%self.mw_family)
        
        # Sample 100 real data samples
        idx = np.random.randint(0, self.real_samples.shape[0], 32)
        real_data_sampled = self.real_samples[idx]
        
        # Find average W2V embeddings for opcode sequences from rela and fake smaples
        word2vec_embeddings_real = []
        for real in real_data_sampled:
            current_embedding = np.zeros(100, dtype=np.float64)
            for val in real:
                current_embedding += model.wv[val]
            word2vec_embeddings_real.append(current_embedding/len(real))
            
        word2vec_embeddings_fake = []
        for fake in self.fake_samples:
            current_embedding = np.zeros(100, dtype=np.float64)
            for val in fake:
                current_embedding += model.wv[val]
            word2vec_embeddings_fake.append(current_embedding/len(fake))
        
        X = word2vec_embeddings_real + word2vec_embeddings_fake
        return np.array(X)
    
    def get_top_20_bigrams(self):
        print('Bi-grams')
        #Calculate top 20 bigrams in real data
        real_data = []
        for opc in self.real_samples:
            real_data.extend(opc)
        
        bigrams = ngrams(real_data, 2)
        bigramsFreq = collections.Counter(bigrams)

        top_20 = set([val[0] for val in bigramsFreq.most_common(20)])
        print(top_20)
        
        # Sample 100 real samples and compute their bigram freq vector of length 20
        idx = np.random.randint(0, self.real_samples.shape[0], 32)
        real_data_sampled = self.real_samples[idx]
        
        real_bigram_vectors = []
        for real in real_data_sampled:
            current_real = []
            bigrams = ngrams(real, 2)
            bigramsFreq = collections.Counter(bigrams)
            for curr_bigram in top_20:
                if curr_bigram in bigramsFreq:
                    current_real.append(bigramsFreq[curr_bigram])
                else:
                    current_real.append(0)
            current_real = np.array(current_real)
            if not np.sum(current_real) == 0:
                current_real = current_real/np.sum(current_real)
            else:
                current_real = current_real.astype(np.float64)
            current_real = current_real/np.sum(current_real)
            real_bigram_vectors.append(current_real)
        
        fake_bigram_vectors = []
        for fake in self.fake_samples:
            current_fake = []
            bigrams = ngrams(fake, 2)
            bigramsFreq = collections.Counter(bigrams)
            for curr_bigram in top_20:
                if curr_bigram in bigramsFreq:
                    current_fake.append(bigramsFreq[curr_bigram])
                else:
                    current_fake.append(0)
                    
            current_fake = np.array(current_fake)        
            if not np.sum(current_fake) == 0:
                current_fake = current_fake/np.sum(current_fake)
            else:
                current_fake = current_fake.astype(np.float64)
            fake_bigram_vectors.append(current_fake)
        
        X = real_bigram_vectors + fake_bigram_vectors
        return np.array(X)
        
    def svm(self, X, y):
        print('******SVM******')
        k = 5
        accuracy = []
        precision = []
        recall = []
        best = 0.
        kf = KFold(n_splits=k, shuffle=True)
        
        for train_index, test_index in kf.split(X):
            X_train, X_test = X[train_index], X[test_index]
            y_train, y_test = y[train_index], y[test_index]
            clf = SVC(C=5, kernel='rbf')
            clf.fit(X_train, y_train)
            acc = clf.score(X_test, y_test)
            accuracy.append(acc)
            if acc>best:
                best = acc
                best_train, best_test = train_index, test_index
                
            y_pred = clf.predict(X_test)
            precision.append(precision_score(y_test, y_pred))
            recall.append(recall_score(y_test, y_pred))
            
        print('\nK-Fold accuracy: ', accuracy)
        print('K-Fold precision: ', precision)
        print('K-Fold recall: ', recall)
        
        
        print('\nAvg K-Fold accuracy: %0.2f'%np.mean(np.array(accuracy)))
        print('Avg K-Fold precision: %0.2f'%np.mean(np.array(precision)))
        print('Avg K-Fold recall: %0.2f\n'%np.mean(np.array(recall)))
        
        X_train, X_test, y_train, y_test = X[best_train], X[best_test], y[best_train], y[best_test]
        clf = SVC(C=5, kernel='rbf')
        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)
        
        fig, ax = plt.subplots(figsize=(4,4))
        plot_confusion_matrix(clf, X_test, y_test, display_labels=np.array(['real', 'fake']), cmap=plt.cm.Blues, ax=ax)
        ax.set_title('%s confusion matrix'%self.mw_family)
        plt.show()
        
        print(classification_report(y_test, y_pred))    
    
    def naive_bayes(self, X, y):
        print('******Naive Bayes******')
        k = 5
        accuracy = []
        precision = []
        recall = []
        best = 0.
        kf = KFold(n_splits=k, shuffle=True, random_state=6357)
        
        for train_index, test_index in kf.split(X):
            X_train, X_test = X[train_index], X[test_index]
            y_train, y_test = y[train_index], y[test_index]
            clf = GaussianNB()
            clf.fit(X_train, y_train)
            acc = clf.score(X_test, y_test)
            accuracy.append(acc)
            if acc>best:
                best = acc
                best_train, best_test = train_index, test_index
                
            y_pred = clf.predict(X_test)
            precision.append(precision_score(y_test, y_pred))
            recall.append(recall_score(y_test, y_pred))
            
        print('\nK-Fold accuracy: ', accuracy)
        print('K-Fold precision: ', precision)
        print('K-Fold recall: ', recall)
        
        print('\nAvg K-Fold accuracy: %0.2f'%np.mean(np.array(accuracy)))
        print('Avg K-Fold precision: %0.2f'%np.mean(np.array(precision)))
        print('Avg K-Fold recall: %0.2f\n'%np.mean(np.array(recall)))
        
        X_train, X_test, y_train, y_test = X[best_train], X[best_test], y[best_train], y[best_test]
        clf = GaussianNB()
        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)
        
        fig, ax = plt.subplots(figsize=(4,4))
        plot_confusion_matrix(clf, X_test, y_test, display_labels=np.array(['real', 'fake']), cmap=plt.cm.Blues, ax=ax)
        ax.set_title('%s confusion matrix'%self.mw_family)
        plt.show()
        
        print(classification_report(y_test, y_pred))    

    def random_forest(self, X, y):
        print('******Random Forest******')
        k = 5
        accuracy = []
        precision = []
        recall = []
        best = 0.
        kf = KFold(n_splits=k, shuffle=True, random_state=6357)
        
        for train_index, test_index in kf.split(X):
            X_train, X_test = X[train_index], X[test_index]
            y_train, y_test = y[train_index], y[test_index]
            clf = RandomForestClassifier(n_estimators=50, max_depth=5)
            clf.fit(X_train, y_train)
            acc = clf.score(X_test, y_test)
            accuracy.append(acc)
            if acc>best:
                best = acc
                best_train, best_test = train_index, test_index
                
            y_pred = clf.predict(X_test)
            precision.append(precision_score(y_test, y_pred))
            recall.append(recall_score(y_test, y_pred))
            
        print('\nK-Fold accuracy: ', accuracy)
        print('K-Fold precision: ', precision)
        print('K-Fold recall: ', recall)
        
        print('\nAvg K-Fold accuracy: %0.2f'%np.mean(np.array(accuracy)))
        print('Avg K-Fold precision: %0.2f'%np.mean(np.array(precision)))
        print('Avg K-Fold recall: %0.2f\n'%np.mean(np.array(recall)))
        
        X_train, X_test, y_train, y_test = X[best_train], X[best_test], y[best_train], y[best_test]
        clf = RandomForestClassifier(n_estimators=50, max_depth=5)
        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)
        
        fig, ax = plt.subplots(figsize=(4,4))
        plot_confusion_matrix(clf, X_test, y_test, display_labels=np.array(['real', 'fake']), cmap=plt.cm.Blues, ax=ax)
        ax.set_title('%s confusion matrix'%self.mw_family)
        plt.show()
        
        print(classification_report(y_test, y_pred))
        
    def knn(self, X, y):
        print('******K-Nearest Neighbors******')
        k = 5
        accuracy = []
        precision = []
        recall = []
        best = 0.
        kf = KFold(n_splits=k, shuffle=True, random_state=18245)
        
        for train_index, test_index in kf.split(X):
            X_train, X_test = X[train_index], X[test_index]
            y_train, y_test = y[train_index], y[test_index]
            clf = KNeighborsClassifier(n_neighbors=6, p=2)
            print(y_train, y_test)
            clf.fit(X_train, y_train)
            acc = clf.score(X_test, y_test)
            accuracy.append(acc)
            if acc>best:
                best = acc
                best_train, best_test = train_index, test_index
                
            y_pred = clf.predict(X_test)
            precision.append(precision_score(y_test, y_pred))
            recall.append(recall_score(y_test, y_pred))
            
        print('\nK-Fold accuracy: ', accuracy)
        print('K-Fold precision: ', precision)
        print('K-Fold recall: ', recall)
        
        print('\nAvg K-Fold accuracy: %0.2f'%np.mean(np.array(accuracy)))
        print('Avg K-Fold precision: %0.2f'%np.mean(np.array(precision)))
        print('Avg K-Fold recall: %0.2f\n'%np.mean(np.array(recall)))
        
        X_train, X_test, y_train, y_test = X[best_train], X[best_test], y[best_train], y[best_test]
        clf = KNeighborsClassifier(n_neighbors=6, p=2)
        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)
        
        fig, ax = plt.subplots(figsize=(4,4))
        plot_confusion_matrix(clf, X_test, y_test, display_labels=np.array(['real', 'fake']), cmap=plt.cm.Blues, ax=ax)
        ax.set_title('%s confusion matrix'%self.mw_family)
        plt.show()
        
        print(classification_report(y_test, y_pred))
        
if __name__=='__main__':
    num_samples = 32
    #family = ['WinWebSec', 'Zbot', 'Renos', 'OnLineGames', 'VBInject']
    '''
    #### WGAN EPOCHS ###
    epochs = [38, 59, 23, 194, 90]
    
    ### GAN EPOCHS ###
    epochs=[5, 2, 9, 1, 1]
    '''
    family = ['WinWebSec', 'WinWebSec', 'WinWebSec', 'WinWebSec', 'WinWebSec']
    '''
    ### WGANHP EPOCHS ###
    #epochs = [172, 154, 128, 132, 58]
    '''
    epochs = [50, 51, 52, 53, 54]
    y = np.array([1]*num_samples + [0]*num_samples)
    
    for i in range(55, 158):
        print('***Starting %s***'%family[0])
        test_runner = fake_GAN_test_runner(family[0], 600, num_samples, i*500, 'WGANGP')

        X = test_runner.word2vec_embed()
        #X = test_runner.get_top_20_bigrams()
        #X = test_runner.integer_vectors()
        
        test_runner.svm(X, y)
        #test_runner.naive_bayes(X, y)
        #test_runner.random_forest(X, y)
        #test_runner.knn(X, y)
        
        print('Done\n\n')
