#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Apr 29 18:39:40 2021

@author: harshittrehan
"""
from multiprocessing import Process, Queue

import os
import tensorflow
import numpy as np
import data_loader as data

from tensorflow.keras.models import load_model

from sklearn.svm import SVC

from sklearn.model_selection import KFold
from sklearn.metrics import recall_score, precision_score


os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
tensorflow.compat.v1.logging.set_verbosity(tensorflow.compat.v1.logging.ERROR)

class fake_GAN_test_best_epoch():
    def __init__(self, mw_family, file_len, num_samples, initial, limit, increment, architecture):
        self.mw_family = mw_family
        self.latent_dim = 100
        self.file_len = file_len
        self.real_samples, self.num_unique = data.real_loader(self.mw_family, 600).load_real(True)
        self.num_samples = num_samples
        self.factor = self.num_unique/2.
        self.initial = initial
        self.limit = limit
        self.increment = increment
        self.architecture = architecture
        print('Family: %s, Num_unique: %d, Num_samples: %d, Factor: %f, (Initial, Limit, Increment) : (%d,%d,%d), Architecture: %s' % (self.mw_family, self.num_unique, self.num_samples, self.factor, self.initial, self.limit, self.increment, self.architecture))
    
    def generate(self, generator):
        noise = np.random.normal(0, 1, (self.num_samples, self.latent_dim))
        gen_samples = generator.predict(noise)
        gen_samples = (gen_samples + 1) * self.factor
        gen_samples = np.rint(gen_samples)
        gen_samples = gen_samples.astype(int)
        gen_samples = np.reshape(gen_samples, (self.num_samples, 600))
        return gen_samples
        
    def test_runner(self, scores):
        y = np.array([1]*self.num_samples + [0]*self.num_samples)
        
        epoch_map = np.zeros(201)
        i=0
        while(self.initial <= self.limit):
            
            generator = load_model('../GAN/%s_Results/Models/%s/%s_generator_%d.hdf5' % (self.architecture, self.mw_family, self.mw_family, self.initial))
            gen_samples = self.generate(generator)
                
            X = self.integer_vectors(gen_samples)
                
            epoch_map[i] += self.svm(X, y)
                
            self.initial += self.increment
            i+=1
            
        #print(epoch_map)
        scores.put(epoch_map)
            
    def integer_vectors(self, fake_samples):
        idx = np.random.randint(0, self.real_samples.shape[0], self.num_samples)
        real_data_sampled = self.real_samples[idx]
        X = np.concatenate((real_data_sampled, fake_samples))
        return X
        
    def svm(self, X, y):
        k = 5
        accuracy = []
        precision = []
        recall = []
        best = 0.
        kf = KFold(n_splits=k, shuffle=True, random_state=6357)
        
        for train_index, test_index in kf.split(X):
            X_train, X_test = X[train_index], X[test_index]
            y_train, y_test = y[train_index], y[test_index]
            clf = SVC(C=5, kernel='rbf')
            clf.fit(X_train, y_train)
            acc = clf.score(X_test, y_test)
            accuracy.append(acc)
            if acc>best:
                best = acc
                best_train, best_test = train_index, test_index
                
            y_pred = clf.predict(X_test)
            precision.append(precision_score(y_test, y_pred))
            recall.append(recall_score(y_test, y_pred))
            
        print('[Epoch Number: %d, SVM Score: %f]' % (self.initial, np.mean(np.array(accuracy))))
        
        return np.mean(np.array(accuracy))
        
if __name__=='__main__':
    family = ['VBInject']
    
    scores = Queue()
    
    objs = [fake_GAN_test_best_epoch(family[0], 600, 32, 0, 100000, 500, 'WGANGP') for i in range(5)]
    procs = []
    
    for obj in objs:
        proc = Process(target=obj.test_runner, args=(scores,))
        proc.start()
        procs.append(proc)
    
    for proc in procs:
        proc.join()
    
    print('*Done*')
    
    l = [scores.get() for _ in range(5)]
    total = np.zeros(201)
    
    for vals in l:
        total += vals
        
    total = total/5
    
    print('Best Model: %d Accuracy: %f'%(np.argmin(total), np.min(total)))
