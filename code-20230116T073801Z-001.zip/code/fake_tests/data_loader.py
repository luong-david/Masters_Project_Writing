#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 19 16:12:30 2021

@author: harshittrehan
"""
import glob
import json
import numpy as np

######################
#                    #
# Load fake samples  #
#                    #
######################
class fake_loader():
    def __init__(self, abbr, file_len):
        self.abbr = abbr
        self.file_len = file_len
        
    def load_fake(self):
        fake_samples = []
        files = glob.glob('fakeSamples/%s/*.txt'%self.abbr)
        print('Fake files: %d'%len(files))
        for file in files:
            with open(file, "r") as fake_rf:
                current_fake = []
                for line in fake_rf:
                    line = line.strip()
                    current_fake.append(int(line))
            fake_samples.append(current_fake)
            
        return np.array(fake_samples)
 
######################
#                    #
# Load real samples  #
#                    #
######################
class real_loader():
    def __init__(self, mw_family, file_len):
        self.mw_family = mw_family
        self.file_len = file_len
        
    def file_size(self, fname):
        sz = 0
        with open(fname, "r") as rf:
            for i,l in enumerate(rf):
                sz = i
                continue
        return sz+1
    
    def load_real(self, tokenize):
        path = '../DATA/malware (opcodes)/'+self.mw_family+'/*.txt'
        files = glob.glob(path)
        print('Real files: %d'%len(files))
        if tokenize:
            with open("opdicts/opdict%s.json"%self.mw_family, "r") as json_file:
                mapping = json.load(json_file)
        data = []
        for file in files:
            if self.file_size(file) >= self.file_len:
                current_file = []
                with open(file, "r") as rf:
                    for line in rf:
                        if len(current_file) < self.file_len:
                            line = line.strip()
                            if tokenize:
                                if line in mapping:
                                    current_file.append(mapping[line])
                                else:
                                    current_file.append(len(mapping))
                            else:
                                current_file.append(line)
                        else:
                            break
                    data.append(current_file)
            else:
                continue
        return np.array(data), len(mapping)