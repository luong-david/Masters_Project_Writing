#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 19 16:33:17 2021

@author: harshittrehan
"""
import os
      
class PRE():
    def __init__(self, abbr, fake_len, num_gammas):
        self.abbr = abbr
        self.fake_len = fake_len
        self.num_gammas = num_gammas
        self.num_samples = int(30000/fake_len)*num_gammas
    
    def fake_files_from_state_seq(self):
        sample_num = 0
        for i in range(self.num_gammas):
            file = "gammas/%s/%d.txt"%(self.abbr, (i+1))
            with open(file, "r") as states_file:
                for i in range(int(30000/self.fake_len)):
                    size=0
                    directory = "fakeSamples/%s"%(self.abbr)
                    if not os.path.exists(directory):
                        os.mkdir(directory)
                    with open("fakeSamples/%s/fake%d.txt"%(self.abbr, sample_num), "w") as wf:
                        for line in states_file:
                            wf.write(line)
                            size+=1
                            if size >= self.fake_len:
                                size=0
                                sample_num += 1
                                break                            
if __name__ == '__main__':
    pre = PRE('zbot', 600, 2)
    pre.fake_files_from_state_seq()
        
        