# -*- coding: utf-8 -*-
"""
@author: @harshit
"""
from __future__ import print_function, division

from data import DATA

import tensorflow
from tensorflow.keras.layers import Add
from tensorflow.keras.layers import Input, Dense, Reshape, Flatten
from tensorflow.keras.layers import BatchNormalization, Activation, LeakyReLU, LayerNormalization
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.optimizers import Adam
#from tensorflow.keras.callbacks import TensorBoard

import os
import matplotlib.pyplot as plt
import json
import numpy as np

class GAN():
    def __init__(self, family, num_unique, alpha, beta_1):
        self.opcode_len = 600
        #self.cols = 1
        self.sample_shape = (self.opcode_len,)
        self.latent_dim = 100
        self.family = family
        self.alpha = alpha
        self.factor = num_unique
        self.beta_1 = beta_1

        print('Alpha: %f, Beta_1: %f, Num unique: %d, Factor: %f'%(self.alpha, self.beta_1, num_unique, self.factor))

        optimizerD = Adam(self.alpha, self.beta_1)
        optimizerG = Adam(0.0002, 0.5)
        #optimizer = SGD(0.0001, 0.1)

        # Build and compile the discriminator
        self.discriminator = self.build_discriminator()
        self.discriminator.compile(loss='binary_crossentropy',
            optimizer=optimizerD,
            metrics=['accuracy'])
        # Build the generator
        self.generator = self.build_generator()

        # The generator takes noise as input and generates imgs
        z = Input(shape=(self.latent_dim,))
        random_input = self.generator(z)

        # For the combined model we will only train the generator
        self.discriminator.trainable = False

        # The discriminator takes generated images as input and determines validity
        validity = self.discriminator(random_input)

        # The combined model  (stacked generator and discriminator)
        # Trains the generator to fool the discriminator
        self.combined = Model(z, validity)
        self.combined.compile(loss='binary_crossentropy', optimizer=optimizerG, metrics='accuracy')


    def build_generator(self):

        model = Sequential()

        model.add(Dense(200, input_dim=self.latent_dim))
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))
        model.add(Dense(400))
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))
        model.add(Dense(800))
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))
        model.add(Dense(np.prod(self.sample_shape), activation='tanh'))
        model.add(Reshape(self.sample_shape))

        model.summary()

        noise = Input(shape=(self.latent_dim,))
        img = model(noise)

        return Model(noise, img)

    def build_discriminator(self):

        model = Sequential()

        model.add(Flatten(input_shape=self.sample_shape))
        model.add(Dense(400))
        model.add(LeakyReLU(alpha=0.2))
        model.add(Dense(200))
        model.add(LeakyReLU(alpha=0.2))
        model.add(Dense(1, activation='sigmoid'))
        model.summary()

        img = Input(shape=self.sample_shape)
        validity = model(img)

        return Model(img, validity)

    #def smooth_negative_labels(self, labels):
     #   alpha = np.random.uniform(0,1,(labels.shape))
      #  labels = labels + alpha*0.3
       # print(labels.shape, labels.min(), labels.max())
        #return labels

    def smooth_positive_labels(self, labels):
        alpha = np.random.uniform(0,1,(labels.shape))
        labels = labels - 0.3 + (alpha*0.5)
        print(labels.shape, labels.min(), labels.max())
        return labels

    def train(self, X_train, num_unique, epochs, batch_size=32, model_interval=50):
        '''
        tensorboard_gen = TensorBoard(
            log_dir='GAN_Results/Losses',
            histogram_freq=0,
            batch_size=batch_size,
            write_graph=True,
            update_freq=500)
        tensorboard_gen.set_model(self.generator)

        tensorboard_disc = TensorBoard(
            log_dir='GAN_Results/TensorboardLoss',
            histogram_freq=0,
            batch_size=batch_size,
            write_graph=True)
        tensorboard_disc.set_model(self.discriminator)
        '''

        factor = num_unique/2
        print('Num unique: %d, Factor: %f'%(num_unique, factor))

        # Load the dataset and rescale to [-1, 1]
        #X_train = np.expand_dims(X_train, axis=2)
        X_train = X_train/factor - 1.
        print(X_train.shape)

        # Adversarial ground truths
        valid = self.smooth_positive_labels(np.ones((batch_size, 1)))
        #valid = np.ones((batch_size, 1))
        #fake = self.smooth_negative_labels(np.zeros((batch_size, 1)))
        fake = np.zeros((batch_size, 1))
        
        # Save losses for each epoch for graphs
        results = {}

        for epoch in range(epochs):
            #if epoch==0:
             #   n_critic = 500
            #else:
             #   n_critic = 1
            #for i in range(n_critic):
            # ---------------------
            #  Train Discriminator
            # ---------------------

            # Select a random batch of images
            idx = np.random.randint(0, X_train.shape[0], batch_size)
            
            real_data = X_train[idx]
            #noise = np.random.random_sample((batch_size, self.latent_dim))
            noise = np.random.normal(0, 1, (batch_size, self.latent_dim))
            # Generate a batch of new images
            gen_samples = self.generator.predict(noise)

            # Train the discriminator
            d_loss_real = self.discriminator.train_on_batch(real_data, valid)
            d_loss_fake = self.discriminator.train_on_batch(gen_samples, fake)
            d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)
            
            #tensorboard_disc.on_epoch_end(epoch, dict({'Discriminator Loss': d_loss[0]}))

            #print('Metrics: ', self.discriminator.metrics_names)

            # ---------------------
            #  Train Generator
            # ---------------------
            #valid = np.ones((batch_size, 1))
            #fake = np.zeros((batch_size, 1))

            noise = np.random.normal(0, 1, (batch_size, self.latent_dim))
            # Train the generator (to have the discriminator label samples as valid)
            g_loss = self.combined.train_on_batch(noise, valid)
            
            #Plot the progress
            print("%d [D loss: %f, D real acc.: %.2f%%, G acc.: %.2f%%, G loss: %f]" % (epoch, d_loss[0], 100*d_loss_real[1], 100*g_loss[1], g_loss[0]))
            
            results[epoch] = [np.float64(d_loss[0]), np.float64(g_loss[0])]

            # If at save interval => save generated image samples
            if epoch % model_interval == 0:
                self.save_model(epoch)

        print('%d Epochs finished.' % (epoch))
        #tensorboard_disc.on_train_end(None)
        return self.plot_losses(results, epochs)

    def save_model(self, epoch):
        path = 'C:/Users/shobhit/Desktop/CS298/GAN/GAN_Results/Models/%s/'%(self.family)
        if not os.path.exists(path):
            os.mkdir(path)
        
        path += '/%s_generator_%d.hdf5' % (self.family, epoch)
        self.generator.save(path, include_optimizer=True, save_format='h5')
    
    def plot_losses(self, results, epochs):
        with open('C:/Users/shobhit/Desktop/CS298/GAN/GAN_Results/Losses/gan_%s_loss_values.json'%self.family, "w") as rf:
            json.dump(results, rf)
        print('Plotting.')
        f_d, ax_d = plt.subplots(figsize=(9,6))
        f_g, ax_g = plt.subplots(figsize=(9,6))
        x = [val for val in range(epochs)]
        d = np.array([losses[0] for _,losses in results.items()])
        g = np.array([losses[1] for _,losses in results.items()])
        ax_d.set_ylabel('Discriminator Loss')
        ax_d.set_xlabel('Epochs')
        ax_g.set_ylabel('Generator Loss')
        ax_g.set_xlabel('Epochs')
        ax_d.plot(x, d, 'r', label='Discriminator loss')
        ax_d.set_title('GAN Discriminator Loss')
        ax_g.plot(x, g, 'b', label='Generator loss')
        ax_g.set_title('GAN Generator Loss')
        return f_d, ax_d, f_g, ax_g
            
if __name__ == '__main__':
    
    family = ['WinWebSec', 'VBInject', 'Renos', 'OnLineGames', 'Zbot']
    for fam in family:
        print('Current family: %s' % (fam))
        data_obj = DATA(fam, 600)
        data_samples, num_unique = data_obj.load_data(True)
        gan = GAN(fam, num_unique, 0.0002, 0.5)
        f_d, ax_d, f_g, ax_g = gan.train(data_samples, num_unique, epochs=10001, batch_size=32, model_interval=200)
        plt.legend(loc='lower right')
        f_d.savefig('C:/Users/shobhit/Desktop/CS298/GAN/GAN_Results/Losses/gan_%s_critic.png'%(fam))
        f_g.savefig('C:/Users/shobhit/Desktop/CS298/GAN/GAN_Results/Losses/gan_%s_generator.png'%(fam))

        '''
        vbinject wws done. generator: 200,400,800 with batch norm. discriminator: 400,200 without batch norm, lr=0.0003
        '''