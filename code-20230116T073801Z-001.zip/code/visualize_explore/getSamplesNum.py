#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 26 10:24:42 2021

@author: harshittrehan
"""
import glob
import os

def file_size(fname):
    sz = 0
    with open(fname, "r") as rf:
        for i,l in enumerate(rf):
            sz = i
            continue
    return sz+1

#rootdir = "C:/Users/shobhit/Desktop/CS298/DATA/Malicia (.txt Opcodes)/"
rootdir = "DATA/malware (opcodes)/"
sizeDict = {}

for _, dirs, _ in os.walk(rootdir):
    for di in dirs:
        print(di)
        files = glob.glob(rootdir + di + "/*.txt")
        file_count = 0
        for file in files:
            if file_size(file) > 1500:
                file_count += 1
        sizeDict[di] = file_count