# -*- coding: utf-8 -*-
"""
Created on Wed Apr 21 17:47:21 2021

@author: @harshit
"""
import os
import glob
import matplotlib.pyplot as plt

class VISUALIZE():
    def __init__(self):
        self.data_path = '../DATA/malware (opcodes)/'
        self.opcodes = 'opcodes/'
        self.obs_seq = 'obs_seq/'
        self.families = [f for f in os.listdir(self.data_path) if not (f.startswith('.') or f.startswith('B'))]
    
    def count_unique_opcodes(self):
        count = {}
        print(self.families)
        for family in self.families:
            family_set = set()
            file = '%sopcodes%s.txt'%(self.opcodes, family)
            with open(file, "r") as rf:
                for line in rf:
                    family_set.add(line)
            count[family] = len(family_set)
        return count
    
    def freq_opcode(self, n):
        freq_count = {}
        for family in self.families:
            opdict = {}
            file = '%sobseq%s.txt'%(self.obs_seq, family)
            with open(file, "r") as rf:
                for line in rf:
                    line = line.strip()
                    if line not in opdict:
                        opdict[line] = 1
                    else:
                        opdict[line] += 1

            tup = sorted(opdict.items(), key=lambda item: item[1], reverse=True)
            freq_count[family]=tup[:n]
        return freq_count
    
    def freq_opcode_overall(self, n):
        freq_count = {}
        for family in self.families:
            file = '%sobseq%s.txt'%(self.obs_seq, family)
            with open(file, "r") as rf:
                for line in rf:
                    line = line.strip()
                    if line not in freq_count:
                        freq_count[line] = 1
                    else:
                        freq_count[line] += 1
                        
        tup = sorted(freq_count.items(), key=lambda item: item[1], reverse=True)
        return tup[:n]
        
    def get_inclusion_count(self, overall_freq):
        included = {}
        for family in self.families:
            family_set = set()
            file = '%sopcodes%s.txt'%(self.opcodes, family)
            with open(file, "r") as rf:
                for line in rf:
                    line = line.strip()
                    family_set.add(line)
                    
            for opcode in overall_freq:
                if opcode in family_set:
                    if opcode not in included:
                        included[opcode] = 1
                    else:
                        included[opcode] += 1 
        return included
    
    def plot_bar(self, included):
        tup = sorted(included.items(), key=lambda x:x[1], reverse=True)
        x = [val[0] for val in tup]
        y = [val[1] for val in tup]
        print(x, y)
        fig, axs = plt.subplots(figsize=(10,7))
        axs.bar(x, y, color='darkblue', width=0.5)
        axs.set_ylabel('Number of families included')
        axs.set_xlabel('Top 40 Opcodes')
        #axs.set_xticks(x)
        #axs.xticks
        plt.xticks(rotation=55)
        plt.show() 
        fig.savefig('Top40OpcodesDistribution.png')
        
if __name__ == "__main__":
    viz = VISUALIZE()
    count = viz.count_unique_opcodes()
    freq_20 = viz.freq_opcode(20)
    freq_40 = viz.freq_opcode(40)
    top_20, top_40 = {}, {}
    for family in freq_20:
        top_20[family] = [val[0] for val in freq_20[family]]
        top_40[family] = [val[0] for val in freq_40[family]]
    
    overall_freq = viz.freq_opcode_overall(40)
    overall_freq = [val[0] for val in overall_freq]
    included = viz.get_inclusion_count(overall_freq)
    viz.plot_bar(included)
    #overall_freq = viz.freq_opcode_overall(40)
    #overall_freq = [val[0] for val in overall_freq]    
    #included = viz.get_inclusion_count(overall_freq)
    
    
    
    
