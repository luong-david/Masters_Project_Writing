# -*- coding: utf-8 -*-

import json
import glob

folders = ['OGTESTS', 'RENTESTS', 'VBITESTS', 'WWSTESTS', 'ZBTESTS']
allFamilies = ['OnLineGames', 'Renos', 'VBInject', 'WinWebSec', 'Zbot']
counts = []
#super_set = set()

opdict = {}

for i in range(5):
    #folder = folders[i]
    family = allFamilies[i]
    files = glob.glob("DATA/malware (opcodes)/%s/*.txt"%family)
    for file in files:
        with open(file, "r") as rf:
            for line in rf:
                line = line.strip()
                if line not in opdict:
                    opdict[line] = 1
                else:
                    opdict[line] += 1
                    
        tup = sorted(opdict.items(), key=lambda item: item[1], reverse=True)
        '''
        opdict = {}
        opdict[family] = tup[:20]
        counts.append(opdict)
        vals = set([val[0] for val in opdict[family]])
        print(vals)
        super_set.update(vals)
        '''
    
#with open('20MostFrequent.json', 'w') as wf:
 #   json.dump(counts, wf)

#top20 = {}        